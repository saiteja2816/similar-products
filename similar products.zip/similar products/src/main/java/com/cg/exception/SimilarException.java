package com.cg.exception;

public class SimilarException extends Exception{


	private static final long serialVersionUID = 1L;

	public SimilarException() {
		super();
		
	}

	public SimilarException(String msg) {
		super(msg);
		
	}

}
